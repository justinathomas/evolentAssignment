﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using ContactManagemet.Models.Repository;
using ContactManagemet.Models.Entities;
using System.Collections.Generic;
using ContactManagemet.Controllers.api;
using System.ComponentModel.DataAnnotations;

namespace ContactManagemet.Tests.RepositoryTests
{
    [TestClass]
    public class ContactRepositoryTest
    {
        private IContactRepository Repo;
        private static int lastContactId;

        public ContactRepositoryTest()
        {
            Repo = new ContactRepository();
        }

        [TestMethod]
        public void ShouldAddContacts()
        {
            Contact contact = new Contact();
            contact.FirstName = "Jus";
            contact.LastName = "Ajmire";
            contact.Email = "justin.ajmire@gmail.com";
            contact.PhoneNumber = "8446100120";
            contact.Status = "Active";
            Contact dbContact = Repo.AddContact(contact);
            Assert.AreEqual(dbContact, contact);
            lastContactId = dbContact.Id;
        }

        [TestMethod]
        public void ShouldListContacts()
        {
            List<Contact> contacts = Repo.ListContact();
            Assert.IsNotNull(contacts);
            Assert.IsTrue(contacts.Count > 0);
        }
        [TestMethod]
        public void ShouldUpdateContacts()
        {
            Contact contact = Repo.GetContact(lastContactId);
            contact.FirstName = "Jhn";
            contact.LastName = "Ennd";
            contact.Email = "Johnd@gmail.com";
            contact.PhoneNumber = "5446100120";
            contact.Status = "Inactive";

            Contact dbContact = Repo.UpdateContact(contact);
            Assert.AreEqual(dbContact.FirstName, contact.FirstName);
            Assert.AreEqual(dbContact.LastName, contact.LastName);
            Assert.AreEqual(dbContact.Email, contact.Email);
            Assert.AreEqual(dbContact.PhoneNumber, contact.PhoneNumber);
            Assert.AreEqual(dbContact.Status, contact.Status);
        }

        [TestMethod]
        public void ShouldDeleteContacts()
        {
            Assert.IsTrue(Repo.DeleteContact(lastContactId));
            Contact contact = Repo.GetContact(lastContactId);
            Assert.IsNull(contact);
        }

        [TestMethod]
        public void ValidateFirstName()
        {
            Contact contact = new Contact();
            contact.FirstName = string.Empty;
            contact.LastName = "Aire";
            contact.Email = "pritire@gmail.com";
            contact.PhoneNumber = "8446100120";
            contact.Status = "Active";
            var results = ContactRepositoryTest.Validate(contact);

            Assert.AreEqual(0, results.Count);
        }

        [TestMethod]
        public void ValidateLastName()
        {
            Contact contact = new Contact();
            contact.FirstName = "Pam";
            contact.LastName = string.Empty;
            contact.Email = "prire@gmail.com";
            contact.PhoneNumber = "8446100120";
            contact.Status = "Active";
            var results = ContactRepositoryTest.Validate(contact);

            Assert.AreEqual(0, results.Count);
        }

        [TestMethod]
        public void ValidateEmail()
        {
            Contact contact = new Contact();
            contact.FirstName = "justin";
            contact.LastName = "thomas";
            contact.Email = string.Empty;
            contact.PhoneNumber = "8446100120";
            contact.Status = "Active";
         
            var results = ContactRepositoryTest.Validate(contact);

            Assert.AreEqual(0, results.Count);
        }

        [TestMethod]
        public void ValidatePhone()
        {
            Contact contact = new Contact();
            contact.FirstName = "justin";
            contact.LastName = "Ajmire";
            contact.Email = "justin.ajmire@gmail.com";
            contact.PhoneNumber = "";
            contact.Status = "Active";
            var results = ContactRepositoryTest.Validate(contact);

            Assert.AreEqual(0, results.Count);
        }

        [TestMethod]
        public void ValidateStatus()
        {
            Contact contact = new Contact();
            contact.FirstName = "justin";
            contact.LastName = "thomad";
            contact.Email = "justin.ajmire@gmail.com";
            contact.PhoneNumber = "8446100120";
            contact.Status = "";
            var results = ContactRepositoryTest.Validate(contact);

            Assert.AreEqual(0, results.Count);
        }

        

        public static IList<ValidationResult> Validate(Contact model)
        {
            var results = new List<ValidationResult>();
            var validationContext = new ValidationContext(model, null, null);
            Validator.TryValidateObject(model, validationContext, results, true);
            if (model is IValidatableObject) (model as IValidatableObject).Validate(validationContext);
            return results;
        }

    }
}
