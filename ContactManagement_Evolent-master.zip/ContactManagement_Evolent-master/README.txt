# ContactManagement_Evolent
Contact Management web application using Asp.net MVC, Enitity Framework and Web API.

Project Description:

Project Description:
Design and implement a production ready application for maintaining contact information. Please choose the frameworks, packages and/or technologies that best suit the requirements. 

### Expected functionality:

add a contact

list contacts

edit contact

delete contact


### Required Contact model:

First Name

Last Name

Email

Phone Number

Status (Possible values: Active/Inactive)


# Getting Started

IDE: Visual Studio 2015

Change connection string in .config files to connect to your database.

Web APP:  Web.config Setup
Location: ~\ContactManagement\Web.config

Test APP: app.config Setup
Location: ~\ContactManagement.Tests\App.config

Databse:
Database Script is located on Contact.sql present in this folder.
You can create table by executing script on your database.

## Thank You
